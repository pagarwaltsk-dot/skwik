# Skwik — Stage 1

Full setup instructions are in the build guide document.

## Short version

1. Create a project at supabase.com (region: Mumbai).
2. SQL Editor > New query > paste ALL of `supabase/schema.sql` > Run. One file, nothing else.
3. Authentication > Sign In / Providers > Email > turn OFF "Confirm email".
4. Project Settings > API > copy the Project URL and the anon public key
   into the first two lines of `src/lib/supabase.js`.
5. On your computer:

       npx create-expo-app@latest skwik --template blank
       cd skwik
       npx expo install @supabase/supabase-js @react-native-async-storage/async-storage \
         react-native-url-polyfill @react-navigation/native @react-navigation/native-stack \
         react-native-screens react-native-safe-area-context expo-print expo-sharing

6. Copy `App.js` and the whole `src` folder into `skwik`, replacing its App.js.
7. `npx expo start` and scan the QR code with Expo Go on your phone.

## What is inside

    App.js                    screens and navigation
    src/theme.js              all colours and shared styles
    src/AppContext.js         who is logged in, which firm
    src/lib/supabase.js       YOUR TWO KEYS GO HERE
    src/lib/money.js          GST, rounding, amount in words
    src/lib/uqc.js            the 45 unit codes the GST portal accepts
    src/lib/hsn.js            HSN search and validation  (READ THE NOTE AT THE TOP)
    src/lib/invoice.js        the printed bill and the account statement
    src/components/Pickers.js the HSN and unit pick-one fields
    src/screens/              one file per screen (Settings is where the
                              shopkeeper edits his firm, numbering and account names)
    supabase/schema.sql       the database — the only SQL you run

## Before you sell this to anyone

`src/lib/hsn.js` carries a STARTER list of 116 common HSN headings, not the
full master of about 20,000. Download the real master from the GST portal and
pass it to `setHsnMaster()`. Nothing else in the app changes.
