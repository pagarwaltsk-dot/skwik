app.json  —  WHAT IT IS AND WHERE IT GOES
=========================================

create-expo-app makes its own app.json when you create the project.
REPLACE that file with this one. Same folder as App.js.

What it sets:
  name        Skwik              the name under the icon on the phone
  slug        skwik              how Expo refers to the project
  package     com.skwik.billing  your app's permanent address on Play Store

ABOUT THE PACKAGE NAME: com.skwik.billing can never be changed once the app
is published to the Play Store. If you would rather it were something else,
change it NOW, before you ever publish. Use only lowercase letters and dots.

NO ICON YET: this file deliberately does not point at an icon or splash
image, so it cannot fail on a missing file. Expo uses its own plain ones.
When you have a logo, save it as assets/icon.png (1024x1024 square) and add
these two lines inside "expo":

    "icon": "./assets/icon.png",
    "splash": { "image": "./assets/icon.png", "resizeMode": "contain", "backgroundColor": "#FAF9F5" },
